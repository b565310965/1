package cn.edu.zucc.personplan.util;

public class BusinessException extends BaseException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BusinessException(String msg){
		super(msg);
	}
}
